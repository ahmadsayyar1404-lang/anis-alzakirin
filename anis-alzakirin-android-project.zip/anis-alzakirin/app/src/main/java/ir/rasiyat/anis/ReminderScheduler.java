package ir.rasiyat.anis;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

final class ReminderScheduler {
    static final String PREFS = "anis_native_reminders";
    static final String KEY_PAYLOAD = "payload";
    private ReminderScheduler() {}

    static void sync(Context context, String json) { sync(context, json, false); }

    private static void sync(Context context, String json, boolean force) {
        try {
            String previous = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PAYLOAD, null);
            if (!force && json.equals(previous)) return;
            cancelAll(context);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PAYLOAD, json).apply();
            JSONObject root = new JSONObject(json);
            JSONArray zekrs = root.optJSONArray("zekrs");
            if (zekrs != null) for (int i = 0; i < zekrs.length(); i++) {
                JSONObject item = zekrs.optJSONObject(i);
                if (item == null) continue;
                scheduleDaily(context, "zekr:" + item.optString("id"), "یادآور زمان ذکر", "زمان گفتن ذکر «" + item.optString("name", "ذکر") + "» فرا رسیده است.", item.optString("time"));
            }
            JSONArray namaz = root.optJSONArray("namazList");
            if (namaz != null) for (int i = 0; i < namaz.length(); i++) {
                JSONObject item = namaz.optJSONObject(i);
                if (item == null) continue;
                scheduleDaily(context, "namaz:" + item.optString("id"), "یادآور نماز قضا", "زمان تعیین‌شده برای «" + item.optString("title", "نماز قضا") + "» فرا رسیده است.", item.optString("time"));
            }
            if (root.optBoolean("motivationalEnabled", false)) {
                int minutes = Math.max(15, root.optInt("motivationalInterval", 60));
                scheduleAfter(context, "motivational", "یادآوری دوستانه برای توشه آخرت", "لحظات ارزشمند عمر را دریابیم و برای فردای ابدی خود گامی برداریم.", minutes * 60_000L);
            }
        } catch (Exception ignored) { }
    }

    static void scheduleDaily(Context context, String id, String title, String message, String time) {
        if (time == null || !time.matches("([01]?[0-9]|2[0-3]):[0-5][0-9]")) return;
        String[] parts = time.split(":");
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0]));
        next.set(Calendar.MINUTE, Integer.parseInt(parts[1]));
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR, 1);
        set(context, id, title, message, next.getTimeInMillis(), "daily");
    }

    static void scheduleAfter(Context context, String id, String title, String message, long delay) {
        set(context, id, title, message, System.currentTimeMillis() + delay, "interval");
    }

    private static void set(Context context, String id, String title, String message, long at, String kind) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        PendingIntent pi = pendingIntent(context, id, title, message, kind);
        if (Build.VERSION.SDK_INT >= 23) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        else manager.set(AlarmManager.RTC_WAKEUP, at, pi);
    }

    static PendingIntent pendingIntent(Context context, String id, String title, String message, String kind) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("message", message);
        intent.putExtra("kind", kind);
        int requestCode = id.hashCode();
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }

    private static void cancelAll(Context context) {
        try {
            JSONObject root = new JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PAYLOAD, "{}"));
            JSONArray zekrs = root.optJSONArray("zekrs");
            if (zekrs != null) for (int i=0;i<zekrs.length();i++) cancel(context, "zekr:" + zekrs.getJSONObject(i).optString("id"));
            JSONArray namaz = root.optJSONArray("namazList");
            if (namaz != null) for (int i=0;i<namaz.length();i++) cancel(context, "namaz:" + namaz.getJSONObject(i).optString("id"));
            cancel(context, "motivational");
        } catch (Exception ignored) { cancel(context, "motivational"); }
    }

    private static void cancel(Context context, String id) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(pendingIntent(context, id, "", "", ""));
    }

    static void restore(Context context) {
        String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PAYLOAD, null);
        if (json != null) sync(context, json, true);
    }
}
