package ir.rasiyat.anis

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max

private val Ink = Color(0xFF26332F)
private val Muted = Color(0xFF7B8781)
private val Primary = Color(0xFF52796F)
private val Canvas = Color(0xFFF6F8F6)
private val SurfaceWhite = Color(0xFFFFFFFF)
private val SoftGreen = Color(0xFFE8F0EC)
private val Border = Color(0xFFE6EBE7)

private fun fa(value: Any?): String = (value?.toString() ?: "").map { if (it in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")

private data class DayRecord(val total: Int = 0, val external: Int = 0)
private data class Zekr(
    val id: String, val name: String, val count: Int = 0, val external: Int = 0,
    val target: Int = 100, val days: Int = 0, val rounds: Int = 0,
    val reminder: String = "", val lastReminded: String = "", val history: Map<String, DayRecord> = emptyMap()
)
private data class Namaz(
    val id: String, val title: String, val mode: String = "daily", val specific: String = "sobh",
    val target: Int = 10, val completed: Int = 0, val external: Int = 0, val rounds: Int = 0,
    val waqfIndex: Int = 0, val rakat: Int = 1, val sajdeh: Int = 0,
    val reminder: String = "", val lastReminded: String = "", val history: Map<String, DayRecord> = emptyMap()
)
private data class AppData(
    val zekrs: List<Zekr> = listOf(
        Zekr("z1", "صلوات", target = 100), Zekr("z2", "استغفار", target = 70, days = 10)
    ),
    val namaz: List<Namaz> = listOf(Namaz("n1", "نماز قضای خودم")),
    val activeZekr: String = "z1", val activeNamaz: String = "n1",
    val motivational: Boolean = false, val motivationalInterval: Int = 60
)

private class Store(context: Context) {
    private val prefs = context.getSharedPreferences("anis_native", Context.MODE_PRIVATE)
    var data by mutableStateOf(read())
        private set
    private fun read(): AppData {
        val raw = prefs.getString("state", null) ?: return AppData()
        return try {
            val root = JSONObject(raw)
            val zs = mutableListOf<Zekr>()
            val za = root.optJSONArray("zekrs") ?: JSONArray()
            for (i in 0 until za.length()) {
                val o = za.getJSONObject(i); zs += Zekr(o.optString("id"), o.optString("name"), o.optInt("count"), o.optInt("external"), o.optInt("target",100), o.optInt("days"), o.optInt("rounds"), o.optString("reminder"), o.optString("lastReminded"), readHistory(o.optJSONObject("history")))
            }
            val ns = mutableListOf<Namaz>()
            val na = root.optJSONArray("namaz") ?: JSONArray()
            for (i in 0 until na.length()) {
                val o = na.getJSONObject(i); ns += Namaz(o.optString("id"),o.optString("title"),o.optString("mode","daily"),o.optString("specific","sobh"),o.optInt("target",10),o.optInt("completed"),o.optInt("external"),o.optInt("rounds"),o.optInt("waqfIndex"),o.optInt("rakat",1),o.optInt("sajdeh"),o.optString("reminder"),o.optString("lastReminded"),readHistory(o.optJSONObject("history")))
            }
            AppData(zs.ifEmpty { AppData().zekrs }, ns.ifEmpty { AppData().namaz }, root.optString("activeZekr", "z1"), root.optString("activeNamaz", "n1"), root.optBoolean("motivational",false), root.optInt("motivationalInterval",60))
        } catch (_: Exception) { AppData() }
    }
    private fun readHistory(o: JSONObject?): Map<String,DayRecord> {
        val out = mutableMapOf<String,DayRecord>(); if (o != null) { val it=o.keys(); while(it.hasNext()){ val k=it.next(); val v=o.optJSONObject(k) ?: continue; out[k]=DayRecord(v.optInt("total"),v.optInt("external")) } }; return out
    }
    private fun historyJson(h: Map<String,DayRecord>): JSONObject { val o=JSONObject(); h.forEach { (k,v)-> o.put(k,JSONObject().put("total",v.total).put("external",v.external)) }; return o }
    private fun write() {
        val root=JSONObject(); val zs=JSONArray(); data.zekrs.forEach { z-> zs.put(JSONObject().put("id",z.id).put("name",z.name).put("count",z.count).put("external",z.external).put("target",z.target).put("days",z.days).put("rounds",z.rounds).put("reminder",z.reminder).put("lastReminded",z.lastReminded).put("history",historyJson(z.history))) }
        val ns=JSONArray(); data.namaz.forEach { n-> ns.put(JSONObject().put("id",n.id).put("title",n.title).put("mode",n.mode).put("specific",n.specific).put("target",n.target).put("completed",n.completed).put("external",n.external).put("rounds",n.rounds).put("waqfIndex",n.waqfIndex).put("rakat",n.rakat).put("sajdeh",n.sajdeh).put("reminder",n.reminder).put("lastReminded",n.lastReminded).put("history",historyJson(n.history))) }
        root.put("zekrs",zs).put("namaz",ns).put("activeZekr",data.activeZekr).put("activeNamaz",data.activeNamaz).put("motivational",data.motivational).put("motivationalInterval",data.motivationalInterval)
        prefs.edit().putString("state",root.toString()).apply()
    }
    init { if (prefs.getString("state", null) == null) write() }
    fun update(transform: (AppData)->AppData) { data=transform(data); write() }
    fun raw(): String = prefs.getString("state", "") ?: ""
}

private fun solarKey(date: Date = Date()): String {
    val cal=Calendar.getInstance().apply { time=date }; var gy=cal.get(Calendar.YEAR); var gm=cal.get(Calendar.MONTH)+1; var gd=cal.get(Calendar.DAY_OF_MONTH)
    val gdm=intArrayOf(0,31,if(isLeap(gy))29 else 28,31,30,31,30,31,31,30,31,30,31)
    var gy2=gy-1600; var gm2=gm-1; var gd2=gd-1
    var gno=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400
    for(i in 0 until gm2) gno+=gdm[i+1]; gno+=gd2
    var jno=gno-79; val jnp=jno/12053; jno%=12053
    var jy=979+33*jnp+4*(jno/1461); jno%=1461
    if(jno>=366){ jy+=(jno-1)/365; jno=(jno-1)%365 }
    val jm=if(jno<186) 1+(jno/31).toInt() else 7+((jno-186)/30).toInt()
    val jd=if(jno<186) 1+(jno%31).toInt() else 1+((jno-186)%30).toInt()
    return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
}
private fun isLeap(y:Int)= y%4==0 && (y%100!=0 || y%400==0)
private val waqfNames=listOf("صبح","ظهر","عصر","مغرب","عشا")
private val waqfKeys=listOf("sobh","zohr","asr","maghrib","isha")
private fun rakats(key:String)=if(key=="sobh")2 else if(key=="maghrib")3 else 4
private fun dayMap(old:Map<String,DayRecord>,delta:Int,external:Boolean):Map<String,DayRecord>{ val k=solarKey(); val r=old[k]?:DayRecord(); val total=max(0,r.total+delta); val ext=if(external) max(0,r.external+delta).coerceAtMost(total) else r.external.coerceAtMost(total); return old+(k to DayRecord(total,ext)) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("anis_reminders","یادآورهای انیس‌الذاکرین",NotificationManager.IMPORTANCE_DEFAULT))
        setContent { AnisApp() }
    }
}

@Composable private fun AnisApp() {
    val context= LocalContext.current
    val store= remember { Store(context) }
    var page by remember { mutableStateOf("ذکرها") }
    var selectedCounter by remember { mutableStateOf("") }
    var counterType by remember { mutableStateOf("zekr") }
    var showAddZekr by remember { mutableStateOf(false) }
    var editZekr by remember { mutableStateOf<Zekr?>(null) }
    var showAddNamaz by remember { mutableStateOf(false) }
    var editNamaz by remember { mutableStateOf<Namaz?>(null) }
    var externalTarget by remember { mutableStateOf<Pair<String,String>?>(null) }
    var showExternal by remember { mutableStateOf(false) }
    var confirmAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var confirmText by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var revealCount by remember { mutableStateOf(false) }
    var reportMonth by remember { mutableIntStateOf(0) }
    var reportCategory by remember { mutableStateOf("zekr") }
    var reportItem by remember { mutableStateOf("") }
    val permissionLauncher= rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) { ReminderScheduler.scheduleAll(context, store.raw()) }

    MaterialTheme(colorScheme=lightColorScheme(primary=Primary,onPrimary=Color.White,background=Canvas,surface=SurfaceWhite,onSurface=Ink,secondary=Color(0xFF91A99F))) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(modifier=Modifier.fillMaxSize(),color=Canvas) {
                if(selectedCounter.isNotBlank()) {
                    CounterScreen(store, counterType, selectedCounter, revealCount, { revealCount=it }, { selectedCounter="" }, { notice=it })
                } else {
                    Scaffold(containerColor=Canvas, bottomBar={
                        NavigationBar(containerColor=SurfaceWhite, tonalElevation=2.dp) {
                            listOf("ذکرها" to Icons.Default.Home,"نماز قضا" to Icons.Default.SelfImprovement,"گزارش" to Icons.Default.BarChart,"تنظیمات" to Icons.Default.Settings).forEach { (label,icon)->
                                NavigationBarItem(selected=page==label,onClick={page=label},icon={Icon(icon,null)},label={Text(label,fontSize=11.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Primary,indicatorColor=SoftGreen,selectedTextColor=Primary,unselectedTextColor=Muted))
                            }
                        }
                    }) { padding ->
                        Column(Modifier.fillMaxSize().padding(padding)) {
                            Header(page)
                            when(page) {
                                "ذکرها" -> ZekrList(store,{ z-> counterType="zekr"; selectedCounter=z.id; revealCount=false },{ showAddZekr=true },{ editZekr=it },{ z->externalTarget="zekr" to z.id;showExternal=true },{ z-> confirmText="ذکر «${z.name}» حذف شود؟"; confirmAction={store.update { d->d.copy(zekrs=d.zekrs.filterNot{it.id==z.id},activeZekr=d.zekrs.firstOrNull{it.id!=z.id}?.id?:"")}} })
                                "نماز قضا" -> NamazList(store,{ n->counterType="namaz";selectedCounter=n.id},{showAddNamaz=true},{editNamaz=it},{ n->externalTarget="namaz" to n.id;showExternal=true },{n->confirmText="«${n.title}» حذف شود؟";confirmAction={store.update{d->d.copy(namaz=d.namaz.filterNot{it.id==n.id},activeNamaz=d.namaz.firstOrNull{it.id!=n.id}?.id?:"")}}})
                                "گزارش" -> ReportScreen(store,reportCategory,{reportCategory=it;reportItem=""},reportItem,{reportItem=it},reportMonth,{reportMonth+=it})
                                else -> SettingsScreen(store,{ if(Build.VERSION.SDK_INT>=33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },{ notice=it })
                            }
                        }
                    }
                }
            }
        }
    }
    if(showAddZekr || editZekr!=null) ZekrDialog(editZekr,{showAddZekr=false;editZekr=null}) { name,target,days,reminder ->
        store.update { d -> if(editZekr!=null) d.copy(zekrs=d.zekrs.map{if(it.id==editZekr!!.id)it.copy(name=name,target=target,days=days,reminder=reminder) else it}) else { val z=Zekr(UUID.randomUUID().toString(),name,target=target,days=days,reminder=reminder); d.copy(zekrs=d.zekrs+z,activeZekr=z.id) } }
        ReminderScheduler.scheduleAll(context,store.raw());showAddZekr=false;editZekr=null
    }
    if(showAddNamaz || editNamaz!=null) NamazDialog(editNamaz,{showAddNamaz=false;editNamaz=null}) { title,mode,specific,target,reminder ->
        store.update { d -> if(editNamaz!=null) d.copy(namaz=d.namaz.map{if(it.id==editNamaz!!.id)it.copy(title=title,mode=mode,specific=specific,target=target,reminder=reminder) else it}) else {val n=Namaz(UUID.randomUUID().toString(),title,mode,specific,target,reminder=reminder);d.copy(namaz=d.namaz+n,activeNamaz=n.id)} }
        ReminderScheduler.scheduleAll(context,store.raw());showAddNamaz=false;editNamaz=null
    }
    if(showExternal && externalTarget!=null) ExternalDialog({showExternal=false}) { amount,plus ->
        val (type,id)=externalTarget!!
        store.update { d -> if(type=="zekr") d.copy(zekrs=d.zekrs.map{z->if(z.id==id){val c=max(0,z.count+(if(plus)amount else -amount));z.copy(count=c,external=max(0,z.external+(if(plus)amount else -amount)).coerceAtMost(c),history=dayMap(z.history,if(plus)amount else -amount,true))}else z}) else d.copy(namaz=d.namaz.map{n->if(n.id==id){val c=max(0,n.completed+(if(plus)amount else -amount));n.copy(completed=c,external=max(0,n.external+(if(plus)amount else -amount)).coerceAtMost(c),history=dayMap(n.history,if(plus)amount else -amount,true))}else n}) }
        showExternal=false
    }
    if(confirmAction!=null) AlertDialog(onDismissRequest={confirmAction=null},title={Text("تأیید عملیات")},text={Text(confirmText)},confirmButton={TextButton(onClick={confirmAction?.invoke();confirmAction=null}){Text("بله، مطمئنم")}},dismissButton={TextButton(onClick={confirmAction=null}){Text("انصراف")}})
    if(notice.isNotBlank()) AlertDialog(onDismissRequest={notice=""},title={Text("انیس‌الذاکرین")},text={Text(notice)},confirmButton={TextButton(onClick={notice=""}){Text("متوجه شدم")}})
}

@Composable private fun Header(page:String){ Column(Modifier.fillMaxWidth().background(SurfaceWhite).padding(horizontal=20.dp, vertical=16.dp)) { Text("انیس‌الذاکرین",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink);Text(page,fontSize=13.sp,color=Muted) } }

@Composable private fun ZekrList(store:Store,onOpen:(Zekr)->Unit,onAdd:()->Unit,onEdit:(Zekr)->Unit,onExternal:(Zekr)->Unit,onDelete:(Zekr)->Unit){
    val d=store.data
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text("ذکرهای من",fontWeight=FontWeight.SemiBold,fontSize=17.sp);FilledTonalButton(onClick=onAdd){Icon(Icons.Default.Add,null);Text("ذکر جدید")}}
        LazyColumn(contentPadding=PaddingValues(start=16.dp,end=16.dp,bottom=24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            items(d.zekrs,key={it.id}){z-> Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=SurfaceWhite),border=androidx.compose.foundation.BorderStroke(1.dp,Border),modifier=Modifier.fillMaxWidth().clickable{onOpen(z)}) {
                Column(Modifier.padding(16.dp)) { Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(z.name,fontWeight=FontWeight.Bold,fontSize=17.sp,color=Ink);Text("${if(z.target>0) "هدف ${fa(z.target)}" else "هدف نامحدود"}${if(z.days>0) "  •  ${fa(z.days)} روز" else ""}",fontSize=12.sp,color=Muted)};Text(if(z.target>0)"${fa(z.count)} / ${fa(z.target)}" else fa(z.count),fontSize=15.sp,fontWeight=FontWeight.Bold,color=Primary)}
                    if(z.target>0){Spacer(Modifier.height(12.dp));LinearProgressIndicator(progress={ (z.count.toFloat()/z.target).coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth().height(6.dp),color=Primary,trackColor=SoftGreen)}
                    Row(Modifier.fillMaxWidth().padding(top=12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick={onExternal(z)}){Text("± ثبت بیرونی")};TextButton(onClick={store.update{it.copy(zekrs=it.zekrs.map{a->if(a.id==z.id)a.copy(count=0,external=0)else a})}}){Icon(Icons.Default.Refresh,null);Text("ازسرگیری")};TextButton(onClick={onEdit(z)}){Icon(Icons.Default.Edit,null);Text("ویرایش")};TextButton(onClick={onDelete(z)}){Icon(Icons.Default.Delete,null);Text("حذف")};Spacer(Modifier.weight(1f));Text("${fa(z.rounds)} دور کامل",fontSize=11.sp,color=Muted,modifier=Modifier.align(Alignment.CenterVertically))}
                }
            } }
        }
    }
}

@Composable private fun NamazList(store:Store,onOpen:(Namaz)->Unit,onAdd:()->Unit,onEdit:(Namaz)->Unit,onExternal:(Namaz)->Unit,onDelete:(Namaz)->Unit){
    val d=store.data
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text("برنامه نماز قضا",fontWeight=FontWeight.SemiBold,fontSize=17.sp);FilledTonalButton(onClick=onAdd){Icon(Icons.Default.Add,null);Text("نماز جدید")}}
        LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=4.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            items(d.namaz,key={it.id}){n-> Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=SurfaceWhite),border=androidx.compose.foundation.BorderStroke(1.dp,Border),modifier=Modifier.fillMaxWidth().clickable{onOpen(n)}){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(n.title,fontWeight=FontWeight.Bold,fontSize=17.sp);Text(if(n.mode=="daily")"برنامه روزانه: پنج وعده" else "${waqfNames[waqfKeys.indexOf(n.specific).coerceAtLeast(0)]} مستقل",fontSize=12.sp,color=Muted)};Text(if(n.target>0)"${fa(n.completed)} / ${fa(n.target)}" else fa(n.completed),fontWeight=FontWeight.Bold,color=Primary)};if(n.target>0){Spacer(Modifier.height(12.dp));LinearProgressIndicator(progress={(n.completed.toFloat()/n.target).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(6.dp),color=Primary,trackColor=SoftGreen)};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick={onExternal(n)}){Text("± ثبت بیرونی")};TextButton(onClick={ store.update { state -> state.copy(namaz=state.namaz.map { a -> if(a.id==n.id) a.copy(completed=0,external=0,waqfIndex=0,rakat=1,sajdeh=0) else a }) } }){Icon(Icons.Default.Refresh,null);Text("ازسرگیری")};TextButton(onClick={onEdit(n)}){Icon(Icons.Default.Edit,null);Text("ویرایش")};TextButton(onClick={onDelete(n)}){Icon(Icons.Default.Delete,null);Text("حذف")};Spacer(Modifier.weight(1f));Text("${fa(n.rounds)} دوره کامل",fontSize=11.sp,color=Muted,modifier=Modifier.align(Alignment.CenterVertically))}}} }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable private fun CounterScreen(store:Store,type:String,id:String,reveal:Boolean,onReveal:(Boolean)->Unit,onBack:()->Unit,onNotice:(String)->Unit){
    val d=store.data; val z=d.zekrs.firstOrNull{it.id==id}; val n=d.namaz.firstOrNull{it.id==id}; val context= LocalContext.current
    var localSajdeh by remember(id){mutableIntStateOf(n?.sajdeh?:0)}
    val title=if(type=="zekr")z?.name?:"ذکر" else n?.title?:"نماز قضا"
    Column(Modifier.fillMaxSize().background(Canvas).padding(20.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)};Column(Modifier.weight(1f)){Text(title,fontSize=18.sp,fontWeight=FontWeight.Bold);Text("برای ثبت، روی دایره ضربه بزنید",fontSize=12.sp,color=Muted)}}
        Spacer(Modifier.height(24.dp))
        if(type=="zekr" && z!=null){
            Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center){
                Box(Modifier.size(280.dp).background(SurfaceWhite,CircleShape).pointerInput(z.count){detectTapGestures(onTap={
                    val next=z.count+1;val done=z.target>0&&next>=z.target
                    store.update{it.copy(zekrs=it.zekrs.map{a->if(a.id==id){if(done)a.copy(count=0,external=0,rounds=a.rounds+1,history=dayMap(a.history,1,false))else a.copy(count=next,history=dayMap(a.history,1,false))}else a})}
                    vibrate(context,12);if(done){onBack();onNotice("ذکر «${z.name}» به حد نصاب رسید و یک دور کامل ثبت شد. قبول باشد!")}
                },onLongPress={onReveal(!reveal)})},contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(if(reveal)fa(z.count) else "● ● ●",fontSize=42.sp,fontWeight=FontWeight.Light,color=Primary);Text(if(z.target>0)"از ${fa(z.target)}" else "هدف نامحدود",fontSize=13.sp,color=Muted);Text("برای نمایش تعداد، لمس را نگه دارید",fontSize=10.sp,color=Muted)}}
            }
            Text("${fa(z.rounds)} دور کامل شده",modifier=Modifier.align(Alignment.CenterHorizontally),color=Muted)
        } else if(n!=null){
            val key=if(n.mode=="daily")waqfKeys[n.waqfIndex.coerceIn(0,4)] else n.specific
            val total=rakats(key);val waqf=waqfNames[waqfKeys.indexOf(key).coerceAtLeast(0)]
            Column(Modifier.weight(1f).fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(if(n.mode=="daily")"${waqfNames[n.waqfIndex.coerceIn(0,4)]} — روز ${fa(n.completed+1)}" else "$waqf — نماز ${fa(n.completed+1)}",color=Muted);Spacer(Modifier.height(18.dp));Text("رکعت ${fa(n.rakat)} از ${fa(total)}",fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(28.dp));Box(Modifier.size(250.dp).background(SurfaceWhite,CircleShape).clickable{
                if(n.sajdeh==0){store.update{it.copy(namaz=it.namaz.map{a->if(a.id==id)a.copy(sajdeh=1)else a})};vibrate(context,20)}else if(n.sajdeh==1){store.update{it.copy(namaz=it.namaz.map{a->if(a.id==id){if(a.rakat<total)a.copy(sajdeh=0,rakat=a.rakat+1) else if(a.mode=="daily"&&a.waqfIndex<4)a.copy(sajdeh=0,rakat=1,waqfIndex=a.waqfIndex+1) else {val next=a.completed+1;val done=a.target>0&&next>=a.target;a.copy(sajdeh=0,rakat=1,waqfIndex=if(a.mode=="daily")0 else a.waqfIndex,completed=if(done)0 else next,external=if(done)0 else a.external,rounds=if(done)a.rounds+1 else a.rounds,history=dayMap(a.history,1,false))}}else a})};vibrate(context,30)}
            },contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(if(n.sajdeh==0)"آماده" else "سجده اول",fontSize=28.sp,color=Primary,fontWeight=FontWeight.SemiBold);Text("برای ثبت سجده ضربه بزنید",fontSize=12.sp,color=Muted)}};Spacer(Modifier.height(18.dp));Text("پس از دو سجده، رکعت بعدی ثبت می‌شود",fontSize=12.sp,color=Muted)}
        }
    }
}

private fun vibrate(context:Context,ms:Long){try{val v=context.getSystemService(Vibrator::class.java);if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(ms,VibrationEffect.DEFAULT_AMPLITUDE))else @Suppress("DEPRECATION") v.vibrate(ms)}catch(_:Exception){}}

@Composable private fun ZekrDialog(edit:Zekr?,onDismiss:()->Unit,onSave:(String,Int,Int,String)->Unit){var name by remember{mutableStateOf(edit?.name?:"")};var target by remember{mutableStateOf((edit?.target?:100).toString())};var days by remember{mutableStateOf((edit?.days?:0).takeIf{it>0}?.toString()?:"")};var reminder by remember{mutableStateOf(edit?.reminder?:"")};var unlimited by remember{mutableStateOf(edit?.target==0)}
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(edit==null)"افزودن ذکر" else "ویرایش ذکر")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){OutlinedTextField(name,{name=it},label={Text("نام ذکر")},singleLine=true);Row(verticalAlignment=Alignment.CenterVertically){Checkbox(unlimited,{unlimited=it});Text("هدف نامحدود")};if(!unlimited)OutlinedTextField(target,{target=it},label={Text("تعداد هدف")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true);OutlinedTextField(days,{days=it},label={Text("مدت دوره به روز (اختیاری)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true);OutlinedTextField(reminder,{reminder=it},label={Text("یادآور روزانه (مثلاً 08:30)")},singleLine=true)}},confirmButton={TextButton(onClick={if(name.isNotBlank())onSave(name,if(unlimited)0 else target.toIntOrNull()?.coerceAtLeast(1)?:100,days.toIntOrNull()?:0,reminder)}){Text("ذخیره")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable private fun NamazDialog(edit:Namaz?,onDismiss:()->Unit,onSave:(String,String,String,Int,String)->Unit){var title by remember{mutableStateOf(edit?.title?:"نماز قضای خودم")};var mode by remember{mutableStateOf(edit?.mode?:"daily")};var specific by remember{mutableStateOf(edit?.specific?:"sobh")};var target by remember{mutableStateOf((edit?.target?:10).toString())};var unlimited by remember{mutableStateOf(edit?.target==0)};var reminder by remember{mutableStateOf(edit?.reminder?:"")}
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(edit==null)"تعریف نماز قضا" else "ویرایش نماز قضا")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("عنوان")},singleLine=true);Text("نوع برنامه");Row{FilterChip(mode=="daily",{mode="daily"},label={Text("روزانه، پنج وعده")});Spacer(Modifier.width(8.dp));FilterChip(mode=="specific",{mode="specific"},label={Text("یک وعده مشخص")})};if(mode=="specific"){Text("انتخاب وعده");Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){waqfKeys.forEachIndexed{i,k->FilterChip(specific==k,{specific=k},label={Text(waqfNames[i],fontSize=10.sp)})}}};Row(verticalAlignment=Alignment.CenterVertically){Checkbox(unlimited,{unlimited=it});Text("هدف نامحدود")};if(!unlimited)OutlinedTextField(target,{target=it},label={Text(if(mode=="daily")"تعداد روز هدف" else "تعداد نماز هدف")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true);OutlinedTextField(reminder,{reminder=it},label={Text("یادآور روزانه (مثلاً 08:30)")},singleLine=true)}},confirmButton={TextButton(onClick={onSave(title.ifBlank{"نماز قضای خودم"},mode,specific,if(unlimited)0 else target.toIntOrNull()?.coerceAtLeast(1)?:10,reminder)}){Text("ذخیره")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable private fun ExternalDialog(onDismiss: () -> Unit, onSave: (Int, Boolean) -> Unit) {
    var amount by remember { mutableStateOf("1") }
    var plus by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت بیرونی") },
        text = {
            Column {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("تعداد") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Row {
                    FilterChip(selected = plus, onClick = { plus = true }, label = { Text("افزودن") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = !plus, onClick = { plus = false }, label = { Text("کسر") })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { amount.toIntOrNull()?.takeIf { it > 0 }?.let { onSave(it, plus) } }) {
                Text("ثبت")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable private fun ReportScreen(store:Store,category:String,onCategory:(String)->Unit,itemId:String,onItem:(String)->Unit,monthOffset:Int,onMonth:(Int)->Unit){val items=if(category=="zekr")store.data.zekrs.map{it.id to it.name}else store.data.namaz.map{it.id to it.title};val chosen=items.firstOrNull{it.first==itemId}?:items.firstOrNull();val history=if(category=="zekr")store.data.zekrs.firstOrNull{it.id==chosen?.first}?.history?: emptyMap() else store.data.namaz.firstOrNull{it.id==chosen?.first}?.history?:emptyMap();val today=solarKey().split("/");val baseYear=today[0].toInt();val baseMonth=today[1].toInt();var year=baseYear;var month=baseMonth+monthOffset;while(month<1){month+=12;year--};while(month>12){month-=12;year++};val days=if(month<=6)31 else if(month<=11)30 else 29;val monthKey="%04d/%02d/".format(Locale.US,year,month);val monthTotal=history.filterKeys{it.startsWith(monthKey)}.values.sumOf{it.total};val week=history.filterKeys{it in last7Keys()}.values.sumOf{it.total}
    Column(Modifier.fillMaxSize().padding(16.dp)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(category=="zekr",{onCategory("zekr")},label={Text("ذکرها")});FilterChip(category=="namaz",{onCategory("namaz")},label={Text("نماز قضا")})};Spacer(Modifier.height(10.dp));if(items.isNotEmpty()){var expanded by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text(chosen?.second?:"انتخاب مورد")};DropdownMenu(expanded,{expanded=false}){items.forEach{DropdownMenuItem(text={Text(it.second)},onClick={onItem(it.first);expanded=false})}}}};Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("${listOf("فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند")[month-1]} ${fa(year)}",fontWeight=FontWeight.Bold);Row{TextButton(onClick={onMonth(-1)}){Text("ماه قبل")};TextButton(onClick={onMonth(1)}){Text("ماه بعد")}}};Card(colors=CardDefaults.cardColors(containerColor=SurfaceWhite),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp)){Text("مجموع این ماه: ${fa(monthTotal)}",fontWeight=FontWeight.SemiBold);Text("مجموع هفت روز اخیر: ${fa(week)}",color=Muted,fontSize=12.sp);Spacer(Modifier.height(10.dp));for(row in 0 until ((days+6)/7)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){for(col in 1..7){val day=row*7+col; if(day<=days){val key=monthKey+"%02d".format(Locale.US,day);val rec=history[key];Box(Modifier.weight(1f).aspectRatio(1f).background(if((rec?.total?:0)>0)SoftGreen else Canvas,RoundedCornerShape(10.dp)),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(fa(day),fontWeight=FontWeight.SemiBold);if((rec?.total?:0)>0)Text(fa(rec!!.total),fontSize=8.sp,color=Primary)}}}else Spacer(Modifier.weight(1f).aspectRatio(1f))}}};Text("روزهای دارای ثبت با رنگ سبز مشخص شده‌اند.",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=8.dp))}};Spacer(Modifier.height(12.dp));Text("جزئیات روزانه",fontWeight=FontWeight.SemiBold);val records=history.filterKeys{it.startsWith(monthKey)}.toList().sortedByDescending{it.first};LazyColumn{items(records){(key,r)->Row(Modifier.fillMaxWidth().padding(vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(fa(key));Text("${fa(r.total)} مورد  •  بیرونی: ${fa(r.external)}",color=Muted)}}}}
}
private fun last7Keys(): Set<String> = (0..6).map{solarKey(Date(System.currentTimeMillis()-it*86400000L))}.toSet()

@Composable private fun SettingsScreen(store: Store, onPermission: () -> Unit, onNotice: (String) -> Unit) {
    val context = LocalContext.current
    val d = store.data
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("تنظیمات و یادآورها", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceWhite), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, null, tint = Primary)
                    Spacer(Modifier.width(8.dp))
                    Text("پیام‌های انگیزشی", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Switch(checked = d.motivational, onCheckedChange = {
                        store.update { old -> old.copy(motivational = it) }
                        ReminderScheduler.scheduleAll(context, store.raw())
                    })
                }
                Text("نمایش پیام‌های کوتاه برای استمرار ذکر", fontSize = 12.sp, color = Muted)
                AnimatedVisibility(d.motivational) {
                    Column {
                        Spacer(Modifier.height(10.dp))
                        Text("فاصله یادآوری: ${fa(d.motivationalInterval)} دقیقه")
                        Slider(
                            value = d.motivationalInterval.toFloat(),
                            onValueChange = {
                                store.update { old -> old.copy(motivationalInterval = it.toInt()) }
                                ReminderScheduler.scheduleAll(context, store.raw())
                            },
                            valueRange = 15f..180f,
                            steps = 10
                        )
                        TextButton(onClick = { onNotice("اکنون بهترین فرصت برای اندوختن توشه‌ای نیکوست؛ لحظات ارزشمند عمر را دریابیم.") }) {
                            Text("مشاهده نمونه پیام انگیزشی")
                        }
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceWhite), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("اعلان‌های اندروید", fontWeight = FontWeight.SemiBold)
                Text("برای دریافت یادآورهای زمان‌بندی‌شده، مجوز اعلان را فعال کنید.", fontSize = 12.sp, color = Muted)
                Spacer(Modifier.height(8.dp))
                Button(onClick = onPermission) { Text("فعال‌سازی مجوز اعلان") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceWhite), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("درباره برنامه", fontWeight = FontWeight.SemiBold)
                Text("انیس‌الذاکرین • نسخه بومی اندروید ۲.۰", fontSize = 12.sp, color = Muted)
                Text("اطلاعات شمارش‌ها روی همین دستگاه ذخیره می‌شود.", fontSize = 12.sp, color = Muted)
            }
        }
    }
}

class ReminderReceiver:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){val title=intent.getStringExtra("title")?:"یادآور انیس‌الذاکرین";val message=intent.getStringExtra("message")?:"زمان ذکر و عبادت فرا رسیده است.";val id=intent.getIntExtra("id",1);val n=NotificationCompat.Builder(context,"anis_reminders").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(message).setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build();if(Build.VERSION.SDK_INT<33||ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)NotificationManagerCompat.from(context).notify(id,n);val interval=intent.getIntExtra("interval",0);if(interval>0)ReminderScheduler.scheduleInterval(context,id,interval) else ReminderScheduler.scheduleOne(context,id,title,message,intent.getStringExtra("time"))} }
class BootReceiver:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){val raw=context.getSharedPreferences("anis_native",Context.MODE_PRIVATE).getString("state","")?:"";ReminderScheduler.scheduleAll(context,raw)}}
private object ReminderScheduler {
    fun scheduleAll(context: Context, raw: String) {
        try {
            val root = JSONObject(raw)
            val lists = listOf("zekrs" to "ذکر", "namaz" to "نماز قضا")
            for ((key, label) in lists) {
                val array = root.optJSONArray(key) ?: continue
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    val time = item.optString("reminder", "")
                    if (time.length >= 4) {
                        val id = item.optString("id").hashCode() and 0x7fffffff
                        val itemName = item.optString(if (key == "zekrs") "name" else "title")
                        scheduleOne(context, id, "یادآور $label", "زمان یادآوری «$itemName» فرا رسیده است.", time)
                    }
                }
            }
            if (root.optBoolean("motivational", false)) {
                scheduleInterval(context, 909, root.optInt("motivationalInterval", 60).coerceAtLeast(15))
            }
        } catch (_: Exception) { }
    }

    fun scheduleInterval(context: Context, id: Int, minutes: Int) {
        try {
            val intent = Intent(context, ReminderReceiver::class.java)
                .putExtra("id", id)
                .putExtra("title", "یادآوری دوستانه برای توشه آخرت")
                .putExtra("message", "لحظاتی برای ذکر و یاد خدا در نظر بگیریم.")
                .putExtra("interval", minutes)
            val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + minutes * 60_000L,
                pending
            )
        } catch (_: Exception) { }
    }

    fun scheduleOne(context: Context, id: Int, title: String, message: String, time: String? = null) {
        try {
            val value = time ?: return
            val parts = value.split(":")
            if (parts.size < 2) return
            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                set(Calendar.MINUTE, parts[1].toInt())
                set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(context, ReminderReceiver::class.java)
                .putExtra("id", id).putExtra("title", title).putExtra("message", message).putExtra("time", value)
            val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)
        } catch (_: Exception) { }
    }
}
